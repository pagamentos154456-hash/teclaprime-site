# TeclaPrime

Site de ecommerce criado para Vercel.

## Como publicar

1. Envie todos os arquivos para um repositório no GitHub.
2. Entre na Vercel.
3. Clique em Add New > Project.
4. Importe o repositório.
5. Clique em Deploy.

Framework: Vite
Build Command: npm run build
Output Directory: dist
