import React from "react";
import { Search, ShoppingCart, User, Menu, Star, Truck, ShieldCheck, CreditCard, MessageCircle } from "lucide-react";
import { motion } from "framer-motion";

const products = [
  {
    name: "Piano Digital Harmonia PX-88",
    oldPrice: "R$ 4.999,00",
    price: "R$ 3.499,00",
    tag: "30% OFF",
    rating: "4.9",
    image: "https://images.unsplash.com/photo-1520523839897-bd0b52f945a0?q=80&w=1200&auto=format&fit=crop",
  },
  {
    name: "Teclado Arranjador Maestro 61",
    oldPrice: "R$ 2.199,00",
    price: "R$ 1.539,00",
    tag: "Oferta",
    rating: "4.8",
    image: "https://images.unsplash.com/photo-1511379938547-c1f69419868d?q=80&w=1200&auto=format&fit=crop",
  },
  {
    name: "Pedal Sustain ProStage",
    oldPrice: "R$ 249,00",
    price: "R$ 174,00",
    tag: "Mais vendido",
    rating: "4.7",
    image: "https://images.unsplash.com/photo-1510915361894-db8b60106cb1?q=80&w=1200&auto=format&fit=crop",
  },
  {
    name: "Suporte X Duplo Reforçado",
    oldPrice: "R$ 399,00",
    price: "R$ 279,00",
    tag: "30% OFF",
    rating: "4.9",
    image: "https://images.unsplash.com/photo-1507838153414-b4b713384a76?q=80&w=1200&auto=format&fit=crop",
  },
];

const categories = ["Pianos Digitais", "Teclados", "Controladores", "Pedais", "Suportes", "Áudio", "Acessórios", "Promoções"];

export default function App() {
  return (
    <div className="site">
      <header className="header">
        <div className="topbar">
          <button className="icon mobile"><Menu size={22} /></button>
          <div className="brand">
            <div className="brandIcon">TP</div>
            <div>
              <h1>TeclaPrime</h1>
              <p>Instrumentos & Áudio</p>
            </div>
          </div>

          <div className="search">
            <input placeholder="Buscar piano digital, teclado, pedal..." />
            <button><Search size={20} /></button>
          </div>

          <div className="actions">
            <button className="login"><User size={20} /> Entrar</button>
            <button className="cart"><ShoppingCart size={20} /> Carrinho</button>
          </div>
        </div>

        <nav className="nav">
          {categories.map((cat) => <a key={cat}>{cat}</a>)}
        </nav>
      </header>

      <main>
        <section className="hero">
          <div className="heroInner">
            <motion.div initial={{ opacity: 0, y: 25 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
              <span className="pill">Mega ofertas em instrumentos</span>
              <h2>Pianos digitais com até 30% OFF</h2>
              <p>Equipamentos selecionados para músicos, igrejas, estúdios e iniciantes. Compra segura, envio rápido e parcelamento facilitado.</p>
              <div className="heroBtns">
                <button className="primary">Comprar agora</button>
                <button className="secondary">Ver catálogo</button>
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.5, delay: 0.1 }} className="heroCard">
              <img src="https://images.unsplash.com/photo-1520523839897-bd0b52f945a0?q=80&w=1200&auto=format&fit=crop" alt="Piano digital" />
              <div className="priceBadge">
                <p>A partir de</p>
                <strong>R$ 279/mês</strong>
              </div>
            </motion.div>
          </div>
        </section>

        <section className="benefits">
          {[{icon: Truck, title: "Envio rápido"}, {icon: ShieldCheck, title: "Compra segura"}, {icon: CreditCard, title: "Até 12x"}, {icon: MessageCircle, title: "Atendimento WhatsApp"}].map(({icon: Icon, title}) => (
            <div key={title} className="benefit">
              <Icon />
              <span>{title}</span>
            </div>
          ))}
        </section>

        <section className="section">
          <div className="sectionHead">
            <div>
              <p>Categorias</p>
              <h3>Compre por departamento</h3>
            </div>
            <button>Ver todos</button>
          </div>
          <div className="categoryGrid">
            {categories.map((cat) => <div key={cat} className="category">{cat}</div>)}
          </div>
        </section>

        <section className="section">
          <div className="sectionHead">
            <div>
              <p>Ofertas</p>
              <h3>Pianos e acessórios em destaque</h3>
            </div>
            <button className="darkBtn">Ver promoções</button>
          </div>

          <div className="products">
            {products.map((p) => (
              <article key={p.name} className="product">
                <div className="productImg">
                  <img src={p.image} alt={p.name} />
                  <span>{p.tag}</span>
                </div>
                <div className="productInfo">
                  <div className="rating"><Star size={16} fill="currentColor" /> {p.rating}</div>
                  <h4>{p.name}</h4>
                  <p className="old">{p.oldPrice}</p>
                  <p className="price">{p.price}</p>
                  <p className="installments">ou em até 12x sem juros</p>
                  <button>Comprar</button>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="newsletter">
          <div>
            <h3>TeclaPrime Club</h3>
            <p>Receba cupons, ofertas relâmpago e lançamentos de instrumentos direto no seu WhatsApp.</p>
          </div>
          <div className="newsletterForm">
            <input placeholder="Seu WhatsApp" />
            <button>Entrar</button>
          </div>
        </section>
      </main>

      <footer>
        <div className="footerGrid">
          <div>
            <h4>TeclaPrime</h4>
            <p>Loja online de instrumentos, teclados, pianos digitais e acessórios.</p>
          </div>
          <div><h5>Institucional</h5><p>Sobre nós<br/>Política de troca<br/>Privacidade</p></div>
          <div><h5>Atendimento</h5><p>WhatsApp<br/>E-mail<br/>Rastrear pedido</p></div>
          <div><h5>Pagamento</h5><p>Pix, cartão e boleto<br/>Parcelamento em até 12x</p></div>
        </div>
      </footer>
    </div>
  );
}
